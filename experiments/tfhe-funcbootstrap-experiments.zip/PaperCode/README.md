NOISE :

Import noise.py in your python and use test_parameter_set
to get the resulting log2 of the noise for each method in the paper.

TIME :

In the CMakeLists in Time/src change the path to tfhe library.

Place yourself in folder Time.

In command line write :
cmake -S . -B ./build
cd build
make
./../bin/executable

Then enter the parameters in order.

NOTE: set offset to (temp1 * halfBg) + (1 << (31 - l * Bgbit)) in
tfhe/src/libtfhe/tgsw
